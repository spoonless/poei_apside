package duree;

public class DureeInvalideException extends Exception {

	private static final long serialVersionUID = 1L;

	public DureeInvalideException() {
		super();
	}

	public DureeInvalideException(String message) {
		super(message);
	}

}
