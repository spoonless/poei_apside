package duree;

/**
 *  Une duree en minutes et en secondes
 *
 */
public class Duree {

	private int secondes;

	/**
	 * Cree une duree egale a zero
	 */
	public Duree() {
	}

	/**
	 * @param secondes La duree en secondes
	 * @throws DureeInvalideException si la duree est negative
	 */
	public Duree(int secondes) throws DureeInvalideException {
		set(secondes / 60, secondes % 60);
	}

	/**
	 * @param minutes Nombre de minutes de la duree
	 * @param secondes Nombre de secondes de la duree
	 * @throws DureeInvalideException Si la duree est negative ou si les secondes sont superieures a 59
	 */
	public Duree(int minutes, int secondes) throws DureeInvalideException {
		set(minutes, secondes);
	}

	/**
	 * @param duree La duree au format mm:ss
	 * @throws DureeInvalideException Si la duree n'a pas le bon format, si la duree est negative ou si les secondes sont superieures a 59
	 */
	public Duree(String duree) throws DureeInvalideException {
		String[] minutesSecondes = duree.split(":");
		if (minutesSecondes.length > 2) {
			throw new DureeInvalideException("La duree " + duree + " est invalide !");
		}
		try {
			if (minutesSecondes.length == 1) {
				this.secondes = Integer.valueOf(duree, 10);
			}
			else {
				set(Integer.valueOf(minutesSecondes[0], 10), Integer.valueOf(minutesSecondes[1], 10));
			}
		} catch (NumberFormatException e) {
			throw new DureeInvalideException(e.getMessage());
		}
	}

	public int getMinutes() {
		return secondes / 60;
	}

	public int getSecondes() {
		return secondes % 60;
	}

	public void ajouter(Duree duree) {
		this.secondes += duree.secondes;
	}

	private void set(int minutes, int secondes) throws DureeInvalideException {
		if (secondes < 0) {
			throw new DureeInvalideException("Le nombre de secondes ne peut pas etre negatif !");
		}
		if (secondes > 59) {
			throw new DureeInvalideException("Le nombre de secondes ne peut pas depasser 59 !");
		}
		if (minutes < 0) {
			throw new DureeInvalideException("Le nombre de minutes ne peut pas etre negatif !");
		}
		this.secondes = minutes * 60 + secondes;
	}

	/**
	 * @return La duree au format mm:ss
	 */
	@Override
	public String toString() {
		return String.format("%d:%02d", getMinutes(), getSecondes());
	}
}
